# DUSK APEX v0.11.0 — Complete Offline Handover

Prepared: 2026-10-25

This ZIP is the complete local handover package for the latest version of
DUSK APEX. No GitHub access is required to play the game, inspect the source,
read the prompts, or rebuild it.

## Fastest way to play

1. Extract this ZIP.
2. Open `01_PLAYABLE_LATEST_GAME/index.html` in Chrome or Edge.
3. Click **RACE**.
4. Press **F11** for full-screen play. Press F11 again to exit.

The playable game is a single self-contained HTML file. It does not need a
server, account, backend, or internet connection.

## Controls

| Action | Control |
|---|---|
| Steer | A/D or Left/Right arrows |
| Accelerate | W or Up arrow |
| Brake / reverse | S or Down arrow |
| Active aero | Space |
| Camera | C |
| Request automatic pit stop | P |
| Choose next pit tyre | T |
| Reset car | R |
| Pause | Esc |
| Browser full screen | F11 |

Press **P before pit entry**. The autopilot uses the pit FAST lane, moves
into the BOX lane at your orange **YOUR GARAGE**, stops for service, exits,
and returns control.

## What is inside this ZIP

- `01_PLAYABLE_LATEST_GAME/` — ready-to-play single-file v0.11.0 game.
- `02_FULL_SOURCE_CODE/` — complete project source and project documents.
- `03_PROMPTS_AND_REQUIREMENTS/` — the governing Master Prompt and
  Boundaries files, plus the recorded user decisions and feedback history.
- `04_TEST_REPORTS_AND_LOGS/` — test report and fresh local test/build logs.
- `05_READY_MADE_ZIPS/` — separate playable-only and source-only ZIPs.
- `06_PROJECT_DOCUMENTATION/` — quick-access copies of the main project docs.
- `FILE_MANIFEST_SHA256.txt` — file list with sizes and SHA-256 hashes.

## Rebuild from source

Requirements: Node.js and npm.

```bash
cd 02_FULL_SOURCE_CODE
npm ci
npm run smoke
npm run build
```

The rebuilt game appears at `dist/index.html`.

For development:

```bash
npm run dev
```

## Latest-version highlights

- Fixed the front-wheel steering bug: wheels now visibly steer using the
  real physics angle, Ackermann geometry and camber.
- Improved cornering sensitivity, yaw response, braking, load-sensitive
  grip and controlled slip.
- Daylight scene instead of sunset.
- New original fictional Aurelia Park layout; generated SVG is included.
- Painted sector-change lines removed.
- Animated marshal-post yellow flags plus HUD/AI yellow-flag behaviour.
- Continuous tapered asphalt pit entry/exit aprons with no soil gap.
- Two-lane pit complex: FAST lane for passing traffic and BOX lane for
  service at nine individual garages.

## Intentionally excluded

- `.git/` metadata and any GitHub credentials/configuration.
- `node_modules/`; it is fully restorable with `npm ci` from
  `package-lock.json`.
- Private assistant/system instructions. The user's own governing prompt
  files and project feedback record are included in folder 03.
