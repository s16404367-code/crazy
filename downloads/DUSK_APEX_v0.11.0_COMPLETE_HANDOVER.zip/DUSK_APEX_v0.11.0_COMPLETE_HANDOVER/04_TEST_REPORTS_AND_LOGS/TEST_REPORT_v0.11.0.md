# DUSK APEX v0.11.0 — Local Test Report

Packaged and retested locally on 2026-10-25. GitHub was not used for this
handover test run.

## Fresh checks performed for this ZIP

### Dependency restore

```bash
npm ci
```

Result: completed successfully. npm reported two audit findings in the
existing dependency tree; dependencies were not changed during packaging.

### Headless race/physics simulation

```bash
npm run smoke
```

Result: **ALL PASS**.

Important checks in the fresh run:

- Circuit length: 3,501.7 m.
- Road ribbon normal faces upward.
- Separate FAST (10.8 m) and BOX (15.4 m) pit lanes and paved aprons exist.
- Front-wheel regression check passed: wheel angle 0.409 rad and yaw rate
  0.74 under the test steering input.
- Stopped-car yellow-sector detection passed.
- Full 9-car race reached the finished state.
- Two AI cars completed pit stops.
- Fresh-run best lap: R. ILVES, 74.53 s.
- Focused pit test passed: a fast-lane car passed a car being serviced
  with 4.6 m separation and then stopped at its own later box.

Full output: `smoke-test-v0.11.0.txt`.

### Production build

```bash
npm run build
```

Result: **SUCCESS**.

- `dist/index.html`: 605.13 kB as reported by Vite.
- Gzip: 162.33 kB as reported by Vite.
- Local `gzip -c` byte count during packaging: 161,393 bytes.

Full output: `build-v0.11.0.txt`.

### DOM cross-check

Result: **99 references checked, 0 missing**.

Output: `dom-check-v0.11.0.txt`.

### Subdirectory serve check

The built single file was copied to a local `/crazy/` folder and served
with Python's HTTP server.

- First load: HTTP 200, 605,313 bytes.
- Refresh: HTTP 200.
- No 404 entries in the server log.

Output: `subdirectory-serve-v0.11.0.txt` and `http-server.log`.

### Circuit SVG

`docs/original-circuit.svg` parsed successfully as valid XML.

Output: `svg-check-v0.11.0.txt`.

## Earlier v0.11 development verification

During v0.11 development, the same smoke suite passed three consecutive
full-race runs after the handling/layout/pit changes. Those runs included
the front-wheel, yellow-flag and two-lane-pit focused checks.

## Not verified by this local package test

- Final real-browser visual appearance.
- Human driving feel and preferred steering sensitivity.
- Physical Chromebook performance.
- Physical touch-device/gamepad behaviour.
- CrazyGames runtime environment.

Those require owner/device testing and are not claimed here.
