# User prompts, decisions and feedback history

This file records the project owner's prompts, choices and testing feedback
available in the DUSK APEX project record.

The two governing files below are included beside this document as exact
copies of the files stored in the project:

- `MASTER_PROMPT_v3.0.md`
- `BOUNDARIES_v3.0.md`

Those files are the source of truth for the original large product prompt
and project boundaries. The release-by-release owner feedback is recorded
below. Private system/assistant instructions are not user project data and
are not included.

---

## 1. Original product request (summary)

Build an original, lightweight, browser-based 3D single-seater racing game:

- Original approximately 3.5 km circuit.
- Player plus 8 AI rivals.
- Fixed-timestep arcade-simulation driving physics.
- Countdown, laps, sectors, positions, gaps, fastest lap and results.
- Soft/Medium/Hard tyres with degradation and pit stops.
- Active aero zones under the same rules for player and AI.
- Optional damage and pit repairs.
- Weather choices affecting grip.
- Procedural graphics and audio.
- Keyboard, touch, gamepad and optional tilt controls.
- Settings, quality choices and local persistence.
- No F1 branding, real drivers/teams, copied real circuits, unlicensed
  models/textures/audio, backend, login, paid APIs or ads.
- AI must use fair physics: no teleporting, impossible grip/speed or
  rubber-banding.
- The game must remain recoverable and never soft-lock.
- Final web build should work from a repository subdirectory and as a
  self-contained playable file/ZIP.

The detailed governing wording is in `MASTER_PROMPT_v3.0.md` and
`BOUNDARIES_v3.0.md`.

## 2. Owner-approved delivery choices

The owner selected/approved:

- Game title: **DUSK APEX**.
- Build the originally phased scope as one combined first release.
- Supply playable and source ZIP files.
- At that stage, use GitHub/GitHub Pages for full-screen testing.
- The assistant should clearly state at the end what the owner needs to do.
- Browser F11 should be used for full-screen play rather than assuming the
  small chat preview is the main playing experience.

This produced the first full playtest version, v0.9.0.

## 3. Owner feedback after v0.9.0

The owner reported, in substance:

1. The track appeared to be on grass.
2. The pit lane was not clearly different from the main circuit.
3. Overall graphics needed improvement.
4. Car graphics and visible movement needed improvement, especially wheels,
   steering and the sense that the car was actually moving/turning.
5. Every driver should have an individual garage/pit box.
6. The car should stop automatically at the correct garage after the
   player requests a pit stop.
7. Web resources could be researched if needed, but the project still had
   to remain original and licence-safe.

### v0.10.0 response to that feedback

- Found and fixed downward-facing track ribbons that caused grass to show
  through the road.
- Added a physical pit divider wall, cones and clearer markings.
- Created nine individual garages; the player's is orange and labelled
  **YOUR GARAGE**.
- Added player pit autopilot with the P key.
- Improved asphalt/grass/pit textures, clouds and reflections.
- Added spoked wheel faces, steering wheel, helmet movement, suspension
  bounce, stronger body motion, opening aero flap and car numbers.

## 4. Owner feedback after v0.10.0

The owner's next message was:

> cornering sensitivy is too bad car front tyres are not moving it is stagnate
>
> why there is sunset kep it osme dal light
>
> taek originl track aailable in web of thoses svgs
>
> and when ther is sector change i can see line in track romeve that lan for sector hange
>
> add yellow flags
>
> car dynamics is too bad please imporve and
>
> pit lan entry and exit there is not connection with pit lan road and tracd there is gap of soil remove it make it align and there is not space for tother to go in pit lan there is only one car gap no second car it will wait the front car is served ?? keep some another line
>
> make these hanges

### How each item was interpreted and implemented in v0.11.0

| Owner feedback | v0.11.0 implementation |
|---|---|
| Cornering sensitivity is bad | Faster steering lock/return; sensitivity slider now changes lock speed as well as amount; range extended to 1.8 |
| Front tyres do not move / stagnant | Removed a bug that reset the calculated front-wheel angle to zero; added Ackermann steering, camber, tread grooves/markers and different left/right wheel speeds |
| Remove sunset, use daylight | Clear-day blue sky, high white sun, white clouds and daylight fog in all weather modes |
| Take an original track from web SVGs | A real circuit was not copied because that would violate the originality/licence boundary. A new fictional SVG-style layout, Aurelia Park, was authored and `original-circuit.svg` was generated from the exact game centreline |
| Remove visible sector-change line | Both painted sector lines removed; sector timing remains internal/HUD only |
| Add yellow flags | 12 animated marshal posts with waved yellow flags, multi-sector detection, HUD warnings and AI slow-down |
| Improve car dynamics | Yaw inertia, stronger lateral limit/brakes, trail-brake and throttle load effects, controlled slip near the limit |
| Pit entry/exit has soil gap and is not aligned | Continuous tapered asphalt apron from road edge to garages, 120 m before entry through 120 m after exit; physics surface is paved |
| Only one-car-wide pit lane; second car waits | Added FAST lane and BOX/service lane. Through traffic passes in the fast lane while another car is serviced in the box lane |

## 5. Latest owner instruction

The owner then requested:

> ok ignore the github integration please give all the data in a zip file
> latest version and prompts i have given to you

This complete handover ZIP was prepared in response. Going forward, local
ZIP delivery should be treated as the requested delivery method unless the
owner later asks to resume GitHub work.

## 6. Standing owner-facing requirements retained

- Always end future work with a clear **WHAT YOU NEED TO DO** section.
- Give honest test labels; do not claim browser/device testing that has not
  happened.
- Keep all game content original and licence-safe.
- The small embedded preview is only a first look; full-screen play should
  use F11.
- Latest delivery preference: provide complete ZIP data and ignore GitHub
  integration.
